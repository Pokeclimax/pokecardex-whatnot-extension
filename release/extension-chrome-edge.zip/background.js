"use strict";(()=>{chrome.runtime.onMessage.addListener(t=>{t&&typeof t=="object"&&t.type==="PCDX_OPEN_LIST"&&chrome.tabs.create({url:chrome.runtime.getURL("list.html")})});})();
